# RiceSales Manager V6 Final

This is the Android project ZIP for GitHub ZIP-upload builds.

## App pages
- Home: daily/monthly/yearly sales, kg, profit, expenses, pending and stock
- Customers: customer/shop list with total kg, total bill, paid and pending
- Customer Account: date-wise delivery ledger, item details and payments
- Sales: selected-date deliveries
- Stock: products, cost, selling price and stock
- Reports: daily/monthly/yearly sales, profit, expenses, net profit and pending

## Default products
- Nasreen — cost 102, sell 107
- Suber — cost 79, sell 85
- Tajmahal — cost 40, sell 45
- Nasreen 2 — cost 95, sell 102

## GitHub
Upload `RiceSalesManager_V5_FINAL.zip` to the repository root.
Then replace `.github/workflows/build-apk.yml` with the contents of `github-workflow.yml`.
The workflow extracts the ZIP, finds `settings.gradle`, builds `assembleDebug`, verifies the APK, and uploads it as an artifact.

Do not rename the ZIP unless you also change the ZIP name in the workflow.
