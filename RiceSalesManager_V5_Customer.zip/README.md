# RiceSales Manager V5 Customer

ZIP-upload friendly Android project.

Pages:
Home, Customers, Customer Account, Stock, Sales, Reports.

Customer account tracks:
- total kg delivered
- total bill
- amount received
- pending amount
- date-wise delivery history
- items/rice varieties per delivery
- record payment

Default rice:
Nasreen 102/107
Suber 79/85
Tajmahal 40/45
Nasreen 2 95/102

GitHub workflow is included for ZIP upload/build.
