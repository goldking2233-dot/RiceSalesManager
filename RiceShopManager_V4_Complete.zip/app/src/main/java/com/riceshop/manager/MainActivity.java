package com.riceshop.manager;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {

    static final int GREEN = Color.rgb(7, 122, 62);
    static final int DARK_GREEN = Color.rgb(5, 94, 43);
    static final int LIGHT = Color.rgb(242, 247, 243);
    static final int TEXT = Color.rgb(35, 45, 38);

    LinearLayout list, root;
    TextView selectedLabel, dayValue, monthValue, yearValue, daySales, monthSales, yearSales, stockValue, netProfitValue;
    SharedPreferences sp;
    Calendar selected = Calendar.getInstance();
    ArrayList<Product> products = new ArrayList<>();
    ArrayList<Sale> sales = new ArrayList<>();
    ArrayList<Expense> expenses = new ArrayList<>();

    static class Product {
        String name;
        double buy, sell, stock;
        Product(String n, double b, double s, double st) {
            name = n; buy = b; sell = s; stock = st;
        }
    }

    static class Sale {
        String date, product;
        double qty, amount, profit;
        Sale(String d, String p, double q, double a, double pr) {
            date = d; product = p; qty = q; amount = a; profit = pr;
        }
    }

    static class Expense {
        String date, note;
        double amount;
        Expense(String d, String n, double a) {
            date = d; note = n; amount = a;
        }
    }

    String money(double n) {
        return "₹" + String.format(Locale.US, "%.2f", n);
    }

    String dateKey(Calendar c) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    String monthKey(Calendar c) {
        return new SimpleDateFormat("yyyy-MM", Locale.US).format(c.getTime());
    }

    String yearKey(Calendar c) {
        return new SimpleDateFormat("yyyy", Locale.US).format(c.getTime());
    }

    String displayDate(Calendar c) {
        return new SimpleDateFormat("dd MMM yyyy", Locale.US).format(c.getTime());
    }

    TextView tv(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(TEXT);
        t.setPadding(12, 10, 12, 10);
        return t;
    }

    GradientDrawable box(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(box(GREEN, 18));
        return b;
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("rice_shop_v4", MODE_PRIVATE);
        load();
        buildUI();
    }

    void load() {
        String p = sp.getString("products", "");
        if (p.isEmpty()) {
            products.add(new Product("Nasreen", 102, 107, 0));
            products.add(new Product("Suber", 79, 85, 0));
            products.add(new Product("Tajmahal", 40, 45, 0));
            products.add(new Product("Nasreen 2", 95, 102, 0));
        } else {
            for (String r : p.split("\\|", -1)) {
                String[] x = r.split("~", -1);
                try {
                    if (x.length >= 4) products.add(new Product(x[0], Double.parseDouble(x[1]), Double.parseDouble(x[2]), Double.parseDouble(x[3])));
                } catch (Exception ignored) {}
            }
        }

        String s = sp.getString("sales", "");
        if (!s.isEmpty()) {
            for (String r : s.split("\\|", -1)) {
                String[] x = r.split("~", -1);
                try {
                    if (x.length >= 5) {
                        sales.add(new Sale(x[0], x[1], Double.parseDouble(x[2]), Double.parseDouble(x[3]), Double.parseDouble(x[4])));
                    }
                } catch (Exception ignored) {}
            }
        }

        String e = sp.getString("expenses", "");
        if (!e.isEmpty()) {
            for (String r : e.split("\\|", -1)) {
                String[] x = r.split("~", -1);
                try {
                    if (x.length >= 3) expenses.add(new Expense(x[0], x[1], Double.parseDouble(x[2])));
                } catch (Exception ignored) {}
            }
        }
    }

    void saveProducts() {
        StringBuilder b = new StringBuilder();
        for (Product p : products) {
            if (b.length() > 0) b.append("|");
            b.append(clean(p.name)).append("~").append(p.buy).append("~").append(p.sell).append("~").append(p.stock);
        }
        sp.edit().putString("products", b.toString()).apply();
    }

    void saveSales() {
        StringBuilder b = new StringBuilder();
        for (Sale s : sales) {
            if (b.length() > 0) b.append("|");
            b.append(s.date).append("~").append(clean(s.product)).append("~").append(s.qty)
             .append("~").append(s.amount).append("~").append(s.profit);
        }
        sp.edit().putString("sales", b.toString()).apply();
    }

    void saveExpenses() {
        StringBuilder b = new StringBuilder();
        for (Expense e : expenses) {
            if (b.length() > 0) b.append("|");
            b.append(e.date).append("~").append(clean(e.note)).append("~").append(e.amount);
        }
        sp.edit().putString("expenses", b.toString()).apply();
    }

    String clean(String s) {
        return s.replace("|", " ").replace("~", " ");
    }

    void buildUI() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        TextView header = tv("🌾  Rice Shop Manager", 22);
        header.setTextColor(Color.WHITE);
        header.setTypeface(null, 1);
        header.setPadding(18, 18, 18, 18);
        header.setBackgroundColor(DARK_GREEN);
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(12, 10, 12, 24);
        scroll.addView(content);

        selectedLabel = tv("", 16);
        selectedLabel.setTypeface(null, 1);
        content.addView(selectedLabel);

        LinearLayout cards1 = new LinearLayout(this);
        cards1.setOrientation(LinearLayout.HORIZONTAL);
        dayValue = card(cards1, "DAY PROFIT");
        monthValue = card(cards1, "MONTH PROFIT");
        yearValue = card(cards1, "YEAR PROFIT");
        content.addView(cards1);

        LinearLayout cards2 = new LinearLayout(this);
        cards2.setOrientation(LinearLayout.HORIZONTAL);
        daySales = card(cards2, "DAY SALES");
        monthSales = card(cards2, "MONTH SALES");
        yearSales = card(cards2, "YEAR SALES");
        content.addView(cards2);

        LinearLayout cards3 = new LinearLayout(this);
        cards3.setOrientation(LinearLayout.HORIZONTAL);
        netProfitValue = card(cards3, "NET PROFIT");
        stockValue = card(cards3, "STOCK");
        TextView empty = card(cards3, "PRODUCTS");
        content.addView(cards3);

        LinearLayout.LayoutParams dateParams = new LinearLayout.LayoutParams(-1, 54);
        dateParams.setMargins(0, 10, 0, 6);
        Button date = button("📅  Select Date");
        date.setOnClickListener(v -> chooseDate());
        content.addView(date, dateParams);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        Button addProduct = button("+ Product");
        addProduct.setOnClickListener(v -> productDialog(-1));
        actions.addView(addProduct, new LinearLayout.LayoutParams(0, 54, 1));

        Button expense = button("+ Expense");
        expense.setOnClickListener(v -> expenseDialog());
        LinearLayout.LayoutParams ex = new LinearLayout.LayoutParams(0, 54, 1);
        ex.setMargins(6, 0, 0, 0);
        actions.addView(expense, ex);

        Button history = button("📋 History");
        history.setOnClickListener(v -> showHistory());
        LinearLayout.LayoutParams hi = new LinearLayout.LayoutParams(0, 54, 1);
        hi.setMargins(6, 0, 0, 0);
        actions.addView(history, hi);

        content.addView(actions);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list);

        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        render();
    }

    TextView card(LinearLayout parent, String label) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(4, 6, 4, 6);
        box.setBackground(box(LIGHT, 16));

        TextView l = tv(label, 10);
        l.setTextColor(GREEN);
        l.setGravity(Gravity.CENTER);

        TextView v = tv("₹0.00", 15);
        v.setTypeface(null, 1);
        v.setGravity(Gravity.CENTER);

        box.addView(l);
        box.addView(v);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 72, 1);
        p.setMargins(3, 3, 3, 3);
        parent.addView(box, p);
        return v;
    }

    void chooseDate() {
        new DatePickerDialog(
            this,
            (v, y, m, d) -> {
                selected.set(y, m, d);
                render();
            },
            selected.get(Calendar.YEAR),
            selected.get(Calendar.MONTH),
            selected.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    double salesForDate(String dk) {
        double n = 0;
        for (Sale s : sales) if (s.date.equals(dk)) n += s.amount;
        return n;
    }

    double profitForDate(String dk) {
        double n = 0;
        for (Sale s : sales) if (s.date.equals(dk)) n += s.profit;
        return n;
    }

    double expensesForDate(String dk) {
        double n = 0;
        for (Expense e : expenses) if (e.date.equals(dk)) n += e.amount;
        return n;
    }

    void render() {
        list.removeAllViews();

        String dk = dateKey(selected);
        String mk = monthKey(selected);
        String yk = yearKey(selected);

        double ds = 0, dp = 0, ms = 0, mp = 0, ys = 0, yp = 0;
        double de = 0, me = 0, ye = 0;

        for (Sale s : sales) {
            if (s.date.equals(dk)) { ds += s.amount; dp += s.profit; }
            if (s.date.startsWith(mk)) { ms += s.amount; mp += s.profit; }
            if (s.date.startsWith(yk)) { ys += s.amount; yp += s.profit; }
        }

        for (Expense e : expenses) {
            if (e.date.equals(dk)) de += e.amount;
            if (e.date.startsWith(mk)) me += e.amount;
            if (e.date.startsWith(yk)) ye += e.amount;
        }

        double net = yp - ye;
        double totalStock = 0;
        for (Product p : products) totalStock += p.stock;

        selectedLabel.setText("Selected Date: " + displayDate(selected));
        dayValue.setText(money(dp));
        monthValue.setText(money(mp));
        yearValue.setText(money(yp));
        daySales.setText(money(ds));
        monthSales.setText(money(ms));
        yearSales.setText(money(ys));
        netProfitValue.setText(money(net));
        stockValue.setText(String.format(Locale.US, "%.1f kg", totalStock));

        TextView expenseInfo = tv(
            "Expenses  •  Day " + money(de) + "   Month " + money(me) + "   Year " + money(ye),
            14
        );
        expenseInfo.setBackground(box(LIGHT, 14));
        list.addView(expenseInfo);

        TextView stockHead = tv("📦  STOCK", 18);
        stockHead.setTypeface(null, 1);
        list.addView(stockHead);

        for (int i = 0; i < products.size(); i++) addProductCard(i, dk);

        TextView report = tv(
            "📊  YEAR SUMMARY\nSales: " + money(ys) +
            "\nGross Profit: " + money(yp) +
            "\nExpenses: " + money(ye) +
            "\nNet Profit: " + money(net),
            15
        );
        report.setBackground(box(LIGHT, 16));
        report.setPadding(14, 14, 14, 14);
        list.addView(report);

        TextView recent = tv("🧾  RECENT SALES", 18);
        recent.setTypeface(null, 1);
        list.addView(recent);

        int shown = 0;
        for (int i = sales.size() - 1; i >= 0 && shown < 10; i--, shown++) {
            Sale s = sales.get(i);
            TextView r = tv(
                s.date + "  •  " + s.product + "  •  " +
                String.format(Locale.US, "%.2f kg", s.qty) +
                "  •  " + money(s.amount) +
                "  •  Profit " + money(s.profit),
                14
            );
            r.setBackground(box(Color.rgb(250, 250, 250), 12));
            list.addView(r);
        }

        if (sales.isEmpty()) list.addView(tv("No sales recorded yet.", 14));
    }

    void addProductCard(int idx, String dk) {
        Product p = products.get(idx);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(12, 12, 12, 12);
        card.setBackground(box(Color.rgb(250, 252, 250), 18));

        TextView name = tv(p.name, 18);
        name.setTypeface(null, 1);
        name.setTextColor(GREEN);
        card.addView(name);

        card.addView(tv(
            "Cost " + money(p.buy) + "   |   Sell " + money(p.sell) +
            "   |   Profit/kg " + money(p.sell - p.buy),
            14
        ));

        TextView st = tv("Stock: " + String.format(Locale.US, "%.2f kg", p.stock), 14);
        card.addView(st);

        EditText qty = new EditText(this);
        qty.setHint("Quantity sold (kg)");
        qty.setInputType(2 | 8192);
        card.addView(qty);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button save = button("Save Sale");
        Button stock = button("Add Stock");
        Button edit = button("Edit");

        row.addView(save, new LinearLayout.LayoutParams(0, 52, 1));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, 52, 1);
        sp.setMargins(5, 0, 0, 0);
        row.addView(stock, sp);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, 52, 1);
        ep.setMargins(5, 0, 0, 0);
        row.addView(edit, ep);
        card.addView(row);

        save.setOnClickListener(v -> {
            try {
                double q = Double.parseDouble(qty.getText().toString());
                if (q <= 0) throw new Exception();
                Product pp = products.get(idx);
                double amount = pp.sell * q;
                double profit = (pp.sell - pp.buy) * q;
                sales.add(new Sale(dk, pp.name, q, amount, profit));
                pp.stock = Math.max(0, pp.stock - q);
                saveProducts();
                saveSales();
                qty.setText("");
                render();
                Toast.makeText(this, "Sale saved", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Enter a valid quantity", Toast.LENGTH_SHORT).show();
            }
        });

        stock.setOnClickListener(v -> addStockDialog(idx));
        edit.setOnClickListener(v -> productDialog(idx));

        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 7, 0, 7);
        list.addView(card, cp);
    }

    void addStockDialog(int idx) {
        EditText q = new EditText(this);
        q.setHint("Stock quantity (kg)");
        q.setInputType(2 | 8192);

        new AlertDialog.Builder(this)
            .setTitle("Add Stock - " + products.get(idx).name)
            .setView(q)
            .setPositiveButton("ADD", (d, w) -> {
                try {
                    double n = Double.parseDouble(q.getText().toString());
                    if (n <= 0) throw new Exception();
                    products.get(idx).stock += n;
                    saveProducts();
                    render();
                } catch (Exception e) {
                    Toast.makeText(this, "Enter valid quantity", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("CANCEL", null)
            .show();
    }

    void productDialog(int idx) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        EditText n = new EditText(this);
        EditText b = new EditText(this);
        EditText s = new EditText(this);
        EditText st = new EditText(this);

        n.setHint("Rice name");
        b.setHint("Cost per kg");
        s.setHint("Sell per kg");
        st.setHint("Opening stock (kg)");
        b.setInputType(2 | 8192);
        s.setInputType(2 | 8192);
        st.setInputType(2 | 8192);

        box.addView(n);
        box.addView(b);
        box.addView(s);
        box.addView(st);

        if (idx >= 0) {
            Product p = products.get(idx);
            n.setText(p.name);
            b.setText(String.valueOf(p.buy));
            s.setText(String.valueOf(p.sell));
            st.setText(String.valueOf(p.stock));
        } else {
            st.setText("0");
        }

        new AlertDialog.Builder(this)
            .setTitle(idx < 0 ? "Add Rice Product" : "Edit Rice Product")
            .setView(box)
            .setPositiveButton(idx < 0 ? "ADD" : "SAVE", (d, w) -> {
                try {
                    String name = n.getText().toString().trim();
                    double buy = Double.parseDouble(b.getText().toString());
                    double sell = Double.parseDouble(s.getText().toString());
                    double stock = Double.parseDouble(st.getText().toString());
                    if (name.isEmpty() || buy < 0 || sell < 0 || stock < 0) throw new Exception();

                    if (idx < 0) products.add(new Product(name, buy, sell, stock));
                    else {
                        Product p = products.get(idx);
                        p.name = name;
                        p.buy = buy;
                        p.sell = sell;
                        p.stock = stock;
                    }

                    saveProducts();
                    render();
                } catch (Exception e) {
                    Toast.makeText(this, "Enter valid details", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("CANCEL", null)
            .show();
    }

    void expenseDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        EditText note = new EditText(this);
        EditText amount = new EditText(this);
        note.setHint("Expense name (rent, transport, etc.)");
        amount.setHint("Amount");
        amount.setInputType(2 | 8192);

        box.addView(note);
        box.addView(amount);

        new AlertDialog.Builder(this)
            .setTitle("Add Expense - " + displayDate(selected))
            .setView(box)
            .setPositiveButton("SAVE", (d, w) -> {
                try {
                    String n = note.getText().toString().trim();
                    double a = Double.parseDouble(amount.getText().toString());
                    if (n.isEmpty() || a <= 0) throw new Exception();
                    expenses.add(new Expense(dateKey(selected), n, a));
                    saveExpenses();
                    render();
                } catch (Exception e) {
                    Toast.makeText(this, "Enter valid expense", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("CANCEL", null)
            .show();
    }

    void showHistory() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(10, 0, 10, 0);

        ScrollView sc = new ScrollView(this);
        sc.addView(box);

        TextView h = tv("SALES HISTORY", 20);
        h.setTypeface(null, 1);
        box.addView(h);

        if (sales.isEmpty()) box.addView(tv("No sales yet.", 14));

        for (int i = sales.size() - 1; i >= 0; i--) {
            Sale s = sales.get(i);
            TextView row = tv(
                s.date + "\n" + s.product +
                "  •  " + String.format(Locale.US, "%.2f kg", s.qty) +
                "  •  Sales " + money(s.amount) +
                "  •  Profit " + money(s.profit),
                14
            );
            row.setBackground(box(LIGHT, 12));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.setMargins(0, 4, 0, 4);
            box.addView(row, rp);
        }

        new AlertDialog.Builder(this)
            .setView(sc)
            .setPositiveButton("CLOSE", null)
            .show();
    }
}
