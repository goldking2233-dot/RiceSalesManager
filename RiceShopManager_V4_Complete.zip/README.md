# Rice Shop Manager V4

Features:
- Day / Month / Year sales
- Day / Month / Year gross profit
- Year net profit after expenses
- Select any date
- Sales history
- Add rice products
- Edit rice products
- Add stock and see current stock
- Stock automatically reduces after a sale
- Expenses: rent, transport, electricity, salary, etc.
- Default products:
  - Nasreen: cost 102, sell 107
  - Suber: cost 79, sell 85
  - Tajmahal: cost 40, sell 45
  - Nasreen 2: cost 95, sell 102
- GitHub Actions workflow included
