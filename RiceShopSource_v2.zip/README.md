# Rice Shop Manager v2
Includes date selection, daily/monthly/yearly sales and profit, recent sales, and product management.
Default products: Nasreen 102/107, Suber 79/85, Tajmahal 40/45, Nasreen 2 95/102.

For GitHub: upload this ZIP as ONE file. Then create the workflow file at `.github/workflows/build-apk.yml` that unzips `RiceShopSource_v2.zip` and runs `gradle assembleDebug`.
