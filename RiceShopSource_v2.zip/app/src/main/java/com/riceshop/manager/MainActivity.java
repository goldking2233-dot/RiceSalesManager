package com.riceshop.manager;
import android.app.*;import android.os.Bundle;import android.graphics.Color;import android.view.*;import android.widget.*;import java.text.*;import java.util.*;
public class MainActivity extends Activity {
 LinearLayout list,root; TextView summary,periodSummary; ArrayList<Product> products=new ArrayList<>(); ArrayList<Sale> sales=new ArrayList<>(); android.content.SharedPreferences sp; Calendar selected=Calendar.getInstance();
 static class Product{String name;double buy,sell;Product(String n,double b,double s){name=n;buy=b;sell=s;}}
 static class Sale{String date,product;double qty,profit;Sale(String d,String p,double q,double f){date=d;product=p;qty=q;profit=f;}}
 String money(double n){return "₹"+String.format(Locale.US,"%.2f",n);}
 String dateKey(Calendar c){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
 String monthKey(Calendar c){return new SimpleDateFormat("yyyy-MM",Locale.US).format(c.getTime());}
 String yearKey(Calendar c){return new SimpleDateFormat("yyyy",Locale.US).format(c.getTime());}
 TextView tv(String s,int z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setPadding(12,10,12,10);return t;}
 public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences("rice",0);load();buildUI();}
 void load(){
  String p=sp.getString("products","");
  if(p.isEmpty()){products.add(new Product("Nasreen",102,107));products.add(new Product("Suber",79,85));products.add(new Product("Tajmahal",40,45));products.add(new Product("Nasreen 2",95,102));}
  else for(String r:p.split("\\|",-1)){String[]x=r.split("~",-1);if(x.length==3)products.add(new Product(x[0],Double.parseDouble(x[1]),Double.parseDouble(x[2])));}
  String s=sp.getString("sales","");
  if(!s.isEmpty())for(String r:s.split("\\|",-1)){String[]x=r.split("~",-1);if(x.length==4)sales.add(new Sale(x[0],x[1],Double.parseDouble(x[2]),Double.parseDouble(x[3])));}
 }
 void saveProducts(){StringBuilder b=new StringBuilder();for(Product p:products){if(b.length()>0)b.append("|");b.append(p.name.replace("|","")).append("~").append(p.buy).append("~").append(p.sell);}sp.edit().putString("products",b.toString()).apply();}
 void saveSales(){StringBuilder b=new StringBuilder();for(Sale s:sales){if(b.length()>0)b.append("|");b.append(s.date).append("~").append(s.product.replace("|","")).append("~").append(s.qty).append("~").append(s.profit);}sp.edit().putString("sales",b.toString()).apply();}
 void buildUI(){
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(12,12,12,12);root.setBackgroundColor(Color.rgb(245,247,245));
  TextView title=tv("🌾 Rice Shop Manager",25);title.setTextColor(Color.WHITE);title.setBackgroundColor(Color.rgb(23,107,58));root.addView(title);
  summary=tv("",17);root.addView(summary);
  LinearLayout period=new LinearLayout(this);period.setOrientation(LinearLayout.HORIZONTAL);
  Button day=new Button(this);day.setText("📅 Day");Button month=new Button(this);month.setText("📆 Month");Button year=new Button(this);year.setText("📊 Year");
  period.addView(day,new LinearLayout.LayoutParams(0,60,1));period.addView(month,new LinearLayout.LayoutParams(0,60,1));period.addView(year,new LinearLayout.LayoutParams(0,60,1));root.addView(period);
  periodSummary=tv("",16);root.addView(periodSummary);
  Button date=new Button(this);date.setText("Select Date");date.setOnClickListener(v->chooseDate());root.addView(date);
  Button add=new Button(this);add.setText("+ Add Rice Product");add.setOnClickListener(v->productDialog(-1));root.addView(add);
  ScrollView sv=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
  setContentView(root);render();
 }
 void chooseDate(){new DatePickerDialog(this,(v,y,m,d)->{selected.set(y,m,d);render();},selected.get(Calendar.YEAR),selected.get(Calendar.MONTH),selected.get(Calendar.DAY_OF_MONTH)).show();}
 void render(){
  list.removeAllViews();String dk=dateKey(selected);double dp=0,ds=0,mp=0,ms=0,yp=0,ys=0;
  for(Sale s:sales){double sv=0;for(Product p:products)if(p.name.equals(s.product))sv=p.sell*s.qty;
   if(s.date.equals(dk)){dp+=s.profit;ds+=sv;}if(s.date.startsWith(monthKey(selected))){mp+=s.profit;ms+=sv;}if(s.date.startsWith(yearKey(selected))){yp+=s.profit;ys+=sv;}}
  summary.setText("Selected: "+dk+"\\nDay Sales: "+money(ds)+"   Day Profit: "+money(dp));
  periodSummary.setText("Month Sales: "+money(ms)+"   Month Profit: "+money(mp)+"\\nYear Sales: "+money(ys)+"   Year Profit: "+money(yp));
  for(int i=0;i<products.size();i++){Product p=products.get(i);LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(8,8,8,8);
   card.addView(tv(p.name+" | Cost "+money(p.buy)+" | Sell "+money(p.sell)+"\\nProfit/kg: "+money(p.sell-p.buy),18));
   EditText q=new EditText(this);q.setHint("Quantity sold (kg)");q.setInputType(2|8192);card.addView(q);
   Button sell=new Button(this);sell.setText("Save Today's Sale");final int idx=i;sell.setOnClickListener(v->{try{double qty=Double.parseDouble(q.getText().toString());if(qty<=0)throw new Exception();Product pp=products.get(idx);sales.add(new Sale(dk,pp.name,qty,(pp.sell-pp.buy)*qty));saveSales();q.setText("");render();Toast.makeText(this,"Sale saved for "+dk,Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Enter quantity",Toast.LENGTH_SHORT).show();}});card.addView(sell);
   Button edit=new Button(this);edit.setText("Edit Product");edit.setOnClickListener(v->productDialog(idx));card.addView(edit);list.addView(card);}
  list.addView(tv("\\nRecent sales",20));for(int i=sales.size()-1;i>=0&&i>=sales.size()-10;i--){Sale s=sales.get(i);list.addView(tv(s.date+" • "+s.product+" • "+s.qty+" kg • Profit "+money(s.profit),15));}
 }
 void productDialog(int idx){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);EditText n=new EditText(this),b=new EditText(this),s=new EditText(this);n.setHint("Rice name");b.setHint("Cost per kg");s.setHint("Sell per kg");b.setInputType(2|8192);s.setInputType(2|8192);box.addView(n);box.addView(b);box.addView(s);
  if(idx>=0){Product p=products.get(idx);n.setText(p.name);b.setText(String.valueOf(p.buy));s.setText(String.valueOf(p.sell));}
  new AlertDialog.Builder(this).setTitle(idx<0?"Add Product":"Edit Product").setView(box).setPositiveButton(idx<0?"Add":"Save",(d,w)->{try{String name=n.getText().toString().trim();double buy=Double.parseDouble(b.getText().toString()),sell=Double.parseDouble(s.getText().toString());if(idx<0)products.add(new Product(name,buy,sell));else{Product p=products.get(idx);p.name=name;p.buy=buy;p.sell=sell;}saveProducts();render();}catch(Exception e){Toast.makeText(this,"Enter valid details",Toast.LENGTH_SHORT).show();}}).setNegativeButton("Cancel",null).show();}
}