package com.riceshop.manager;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int GREEN=Color.rgb(7,122,62), DARK=Color.rgb(5,94,43), LIGHT=Color.rgb(242,247,243), TEXT=Color.rgb(35,45,38);
    LinearLayout content; TextView title; SharedPreferences sp;
    ArrayList<Product> products=new ArrayList<>();
    ArrayList<Customer> customers=new ArrayList<>();
    ArrayList<Delivery> deliveries=new ArrayList<>();
    ArrayList<Expense> expenses=new ArrayList<>();
    Calendar selected=Calendar.getInstance();

    static class Product { String n; double buy,sell,stock; Product(String n,double b,double s,double st){this.n=n;buy=b;sell=s;stock=st;} }
    static class Customer { String name,phone; Customer(String n,String p){name=n;phone=p;} }
    static class Delivery {
        String date, customer; double kg,bill,paid;
        String items;
        Delivery(String d,String c,double k,double b,double p,String i){date=d;customer=c;kg=k;bill=b;paid=p;items=i;}
        double pending(){return Math.max(0,bill-paid);}
    }
    static class Expense { String date,note; double amount; Expense(String d,String n,double a){date=d;note=n;amount=a;} }

    TextView tv(String s,float z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(TEXT);t.setPadding(14,10,14,10);return t;}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackground(bg(GREEN,18));return b;}
    String money(double n){return "₹"+String.format(Locale.US,"%.2f",n);}
    String dk(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.getTime());}
    String mk(){return new SimpleDateFormat("yyyy-MM",Locale.US).format(selected.getTime());}
    String yk(){return new SimpleDateFormat("yyyy",Locale.US).format(selected.getTime());}
    String date(Calendar c){return new SimpleDateFormat("dd MMM yyyy",Locale.US).format(c.getTime());}

    @Override public void onCreate(Bundle b){
        super.onCreate(b); sp=getSharedPreferences("rice_v5_customer",0); load(); ui(); showHome();
    }

    void load(){
        products.clear(); customers.clear(); deliveries.clear(); expenses.clear();
        String p=sp.getString("products","");
        if(p.isEmpty()){
            products.add(new Product("Nasreen",102,107,0)); products.add(new Product("Suber",79,85,0));
            products.add(new Product("Tajmahal",40,45,0)); products.add(new Product("Nasreen 2",95,102,0));
        } else for(String r:p.split("\\|",-1)){String[] x=r.split("~",-1);try{if(x.length>=4)products.add(new Product(x[0],Double.parseDouble(x[1]),Double.parseDouble(x[2]),Double.parseDouble(x[3])));}catch(Exception e){}}
        String c=sp.getString("customers","");
        for(String r:c.split("\\|",-1)){if(r.isEmpty())continue;String[] x=r.split("~",-1);if(x.length>=2)customers.add(new Customer(x[0],x[1]));}
        String d=sp.getString("deliveries","");
        for(String r:d.split("\\|",-1)){if(r.isEmpty())continue;String[] x=r.split("~",-1);try{if(x.length>=6)deliveries.add(new Delivery(x[0],x[1],Double.parseDouble(x[2]),Double.parseDouble(x[3]),Double.parseDouble(x[4]),x[5]));}catch(Exception e){}}
        String e=sp.getString("expenses","");
        for(String r:e.split("\\|",-1)){if(r.isEmpty())continue;String[] x=r.split("~",-1);try{if(x.length>=3)expenses.add(new Expense(x[0],x[1],Double.parseDouble(x[2])));}catch(Exception z){}}
    }

    String clean(String x){return x.replace("|"," ").replace("~"," ");}
    void save(){
        StringBuilder p=new StringBuilder(); for(Product x:products){if(p.length()>0)p.append("|");p.append(clean(x.n)).append("~").append(x.buy).append("~").append(x.sell).append("~").append(x.stock);}
        StringBuilder c=new StringBuilder(); for(Customer x:customers){if(c.length()>0)c.append("|");c.append(clean(x.name)).append("~").append(clean(x.phone));}
        StringBuilder d=new StringBuilder(); for(Delivery x:deliveries){if(d.length()>0)d.append("|");d.append(x.date).append("~").append(clean(x.customer)).append("~").append(x.kg).append("~").append(x.bill).append("~").append(x.paid).append("~").append(clean(x.items));}
        StringBuilder e=new StringBuilder(); for(Expense x:expenses){if(e.length()>0)e.append("|");e.append(x.date).append("~").append(clean(x.note)).append("~").append(x.amount);}
        sp.edit().putString("products",p.toString()).putString("customers",c.toString()).putString("deliveries",d.toString()).putString("expenses",e.toString()).apply();
    }

    void ui(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(16,8,16,8);head.setBackgroundColor(DARK);
        title=tv("🌾  RiceSales Manager",21);title.setTextColor(Color.WHITE);title.setTypeface(null,1);head.addView(title,new LinearLayout.LayoutParams(-1,60));root.addView(head);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(12,8,12,8);
        ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setPadding(3,3,3,3);
        String[] labels={"🏠\nHome","👥\nCustomers","📦\nStock","🧾\nSales","📊\nReports"};
        for(int i=0;i<5;i++){final int n=i;TextView b=tv(labels[i],10);b.setGravity(Gravity.CENTER);b.setTextColor(GREEN);b.setBackground(bg(LIGHT,12));b.setOnClickListener(v->{if(n==0)showHome();else if(n==1)showCustomers();else if(n==2)showStock();else if(n==3)showSales();else showReports();});LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,64,1);q.setMargins(2,2,2,2);nav.addView(b,q);}
        root.addView(nav);setContentView(root);
    }

    void clear(String name){content.removeAllViews();title.setText("🌾  "+name);}
    TextView section(String s){TextView t=tv(s,19);t.setTypeface(null,1);t.setTextColor(GREEN);return t;}
    double salesFor(String prefix){double n=0;for(Delivery d:deliveries)if(d.date.startsWith(prefix))n+=d.bill;return n;}
    double paidFor(String prefix){double n=0;for(Delivery d:deliveries)if(d.date.startsWith(prefix))n+=d.paid;return n;}
    double kgFor(String prefix){double n=0;for(Delivery d:deliveries)if(d.date.startsWith(prefix))n+=d.kg;return n;}
    double pendingFor(String prefix){double n=0;for(Delivery d:deliveries)if(d.date.startsWith(prefix))n+=d.pending();return n;}
    double expenseFor(String prefix){double n=0;for(Expense e:expenses)if(e.date.startsWith(prefix))n+=e.amount;return n;}
    double grossProfitFor(String prefix){double n=0;for(Delivery d:deliveries)if(d.date.startsWith(prefix)){n+=profitFromItems(d.items);}return n;}
    double profitFromItems(String items){double n=0;for(String item:items.split(";")){if(item.trim().isEmpty())continue;String[] x=item.split(",");if(x.length>=3){try{String pn=x[0];double q=Double.parseDouble(x[1]), price=Double.parseDouble(x[2]);for(Product p:products)if(p.n.equals(pn))n+=(price-p.buy)*q;}catch(Exception e){}}}return n;}
    double totalStock(){double n=0;for(Product p:products)n+=p.stock;return n;}

    void showHome(){
        clear("Home"); content.addView(tv("📅 "+date(selected),16));
        LinearLayout a=new LinearLayout(this);content.addView(a); stat(a,"TODAY SALES",money(salesFor(dk())));stat(a,"TODAY KG",String.format(Locale.US,"%.1f kg",kgFor(dk())));stat(a,"TODAY PROFIT",money(grossProfitFor(dk())));
        LinearLayout b=new LinearLayout(this);content.addView(b);stat(b,"MONTH SALES",money(salesFor(mk())));stat(b,"MONTH PAID",money(paidFor(mk())));stat(b,"MONTH PENDING",money(pendingFor(mk())));
        LinearLayout c=new LinearLayout(this);content.addView(c);stat(c,"YEAR SALES",money(salesFor(yk())));stat(c,"NET PROFIT",money(grossProfitFor(yk())-expenseFor(yk())));stat(c,"STOCK",String.format(Locale.US,"%.1f kg",totalStock()));
        Button d=btn("📅 Select Date");d.setOnClickListener(v->pickDate(false));content.addView(d);
        content.addView(section("🚚 Today's Delivery"));
        int count=0;for(Delivery x:deliveries)if(x.date.equals(dk()))count++;
        content.addView(tv(count+" customers  •  "+String.format(Locale.US,"%.1f kg",kgFor(dk()))+"  •  "+money(salesFor(dk())),14));
        Button ex=btn("+ Expense");ex.setOnClickListener(v->expenseDialog());content.addView(ex);
    }
    void stat(LinearLayout p,String n,String v){TextView t=tv(n+"\n"+v,12);t.setGravity(Gravity.CENTER);t.setTypeface(null,1);t.setBackground(bg(LIGHT,14));LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(0,76,1);x.setMargins(2,2,2,2);p.addView(t,x);}

    void showCustomers(){
        clear("Customers");
        Button add=btn("+ Add Customer");add.setOnClickListener(v->customerDialog());content.addView(add);
        EditText search=new EditText(this);search.setHint("Search customer");content.addView(search);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable render=()->{list.removeAllViews();String q=search.getText().toString().toLowerCase(Locale.US);for(int i=0;i<customers.size();i++){Customer c=customers.get(i);if(!c.name.toLowerCase(Locale.US).contains(q))continue;double kg=0,b=0,p=0;for(Delivery d:deliveries)if(d.customer.equals(c.name)){kg+=d.kg;b+=d.bill;p+=d.pending();}TextView row=tv(c.name+"\n"+String.format(Locale.US,"%.1f kg",kg)+"  •  Bill "+money(b)+"  •  Pending "+money(p),15);row.setBackground(bg(LIGHT,15));row.setOnClickListener(v->showCustomer(c.name));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,5,0,5);list.addView(row,rp);}};
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){render.run();}public void afterTextChanged(android.text.Editable e){}});render.run();
    }

    void showCustomer(String name){
        clear(name);
        double kg=0,bill=0,paid=0;for(Delivery d:deliveries)if(d.customer.equals(name)){kg+=d.kg;bill+=d.bill;paid+=d.paid;}
        content.addView(tv("📦 Total Rice: "+String.format(Locale.US,"%.1f kg",kg)+"\n💰 Total Bill: "+money(bill)+"\n💵 Received: "+money(paid)+"\n🔴 Pending: "+money(bill-paid),17));
        Button pay=btn("💵 Record Payment");pay.setOnClickListener(v->paymentDialog(name));content.addView(pay);
        Button del=btn("🚚 New Delivery");del.setOnClickListener(v->deliveryDialog(name));content.addView(del);
        content.addView(section("📅 Date-wise Delivery History"));
        for(int i=deliveries.size()-1;i>=0;i--){Delivery d=deliveries.get(i);if(!d.customer.equals(name))continue;TextView r=tv(d.date+"\n"+String.format(Locale.US,"%.1f kg",d.kg)+"  •  Bill "+money(d.bill)+"  •  Received "+money(d.paid)+"  •  Pending "+money(d.pending())+"\n"+d.items.replace(";", " | "),14);r.setBackground(bg(LIGHT,14));content.addView(r);}
    }

    void showStock(){
        clear("Stock");Button add=btn("+ Add Rice Product");add.setOnClickListener(v->productDialog(-1));content.addView(add);
        for(int i=0;i<products.size();i++){Product p=products.get(i);LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(12,10,12,10);c.setBackground(bg(LIGHT,16));c.addView(tv(p.n,18));c.addView(tv("Cost "+money(p.buy)+" | Sell "+money(p.sell)+" | Stock "+String.format(Locale.US,"%.1f kg",p.stock),14));LinearLayout r=new LinearLayout(this);Button plus=btn("Add Stock");plus.setOnClickListener(v->addStock(i));Button edit=btn("Edit");edit.setOnClickListener(v->productDialog(i));r.addView(plus,new LinearLayout.LayoutParams(0,52,1));LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,52,1);ep.setMargins(6,0,0,0);r.addView(edit,ep);c.addView(r);content.addView(c);}
    }

    void showSales(){
        clear("Sales");Button dateBtn=btn("📅 Date: "+date(selected));dateBtn.setOnClickListener(v->pickDate(true));content.addView(dateBtn);
        Button add=btn("🚚 New Customer Delivery");add.setOnClickListener(v->deliveryDialog(customers.isEmpty()?"":customers.get(0).name));content.addView(add);
        content.addView(section("Today's / Selected Date Sales"));
        for(Delivery d:deliveries)if(d.date.equals(dk()))content.addView(tv(d.customer+"  •  "+String.format(Locale.US,"%.1f kg",d.kg)+"  •  "+money(d.bill)+"  •  Pending "+money(d.pending()),14));
    }

    void showReports(){
        clear("Reports");Button d=btn("📅 Change Date");d.setOnClickListener(v->pickDate(false));content.addView(d);
        double ds=salesFor(dk()),dp=grossProfitFor(dk()),de=expenseFor(dk()),ms=salesFor(mk()),mp=grossProfitFor(mk()),me=expenseFor(mk()),ys=salesFor(yk()),yp=grossProfitFor(yk()),ye=expenseFor(yk());
        content.addView(section("Daily"));content.addView(tv("Rice: "+String.format(Locale.US,"%.1f kg",kgFor(dk()))+"\nSales: "+money(ds)+"\nProfit: "+money(dp)+"\nExpenses: "+money(de)+"\nNet: "+money(dp-de)+"\nPending: "+money(pendingFor(dk())),15));
        content.addView(section("Monthly"));content.addView(tv("Rice: "+String.format(Locale.US,"%.1f kg",kgFor(mk()))+"\nSales: "+money(ms)+"\nProfit: "+money(mp)+"\nExpenses: "+money(me)+"\nNet: "+money(mp-me)+"\nPending: "+money(pendingFor(mk())),15));
        content.addView(section("Yearly"));content.addView(tv("Rice: "+String.format(Locale.US,"%.1f kg",kgFor(yk()))+"\nSales: "+money(ys)+"\nProfit: "+money(yp)+"\nExpenses: "+money(ye)+"\nNet: "+money(yp-ye)+"\nPending: "+money(pendingFor(yk())),15));
    }

    void customerDialog(){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);EditText n=new EditText(this),p=new EditText(this);n.setHint("Customer / Shop name");p.setHint("Phone number");b.addView(n);b.addView(p);new AlertDialog.Builder(this).setTitle("Add Customer").setView(b).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{String name=n.getText().toString().trim();if(name.isEmpty())return;customers.add(new Customer(name,p.getText().toString().trim()));save();showCustomers();}).show();}

    void deliveryDialog(String preset){
        if(customers.isEmpty()){customerDialog();return;}
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);
        Spinner cs=new Spinner(this);String[] names=new String[customers.size()];for(int i=0;i<customers.size();i++)names[i]=customers.get(i).name;cs.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));for(int i=0;i<names.length;i++)if(names[i].equals(preset))cs.setSelection(i);b.addView(cs);
        EditText q=new EditText(this);q.setHint("Total rice quantity (kg)");q.setInputType(2|8192);b.addView(q);
        EditText amount=new EditText(this);amount.setHint("Total bill amount");amount.setInputType(2|8192);b.addView(amount);
        EditText paid=new EditText(this);paid.setHint("Amount received now");paid.setInputType(2|8192);b.addView(paid);
        EditText items=new EditText(this);items.setHint("Items: Nasreen,30,107;Suber,20,85");b.addView(items);
        new AlertDialog.Builder(this).setTitle("New Delivery").setView(b).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{try{double kg=Double.parseDouble(q.getText().toString()),bill=Double.parseDouble(amount.getText().toString()),p=paid.getText().toString().isEmpty()?0:Double.parseDouble(paid.getText().toString());String item=items.getText().toString();deliveries.add(new Delivery(dk(),cs.getSelectedItem().toString(),kg,bill,p,item));updateStockFromItems(item);save();showCustomer(cs.getSelectedItem().toString());}catch(Exception e){Toast.makeText(this,"Enter valid delivery details",Toast.LENGTH_SHORT).show();}}).show();
    }

    void updateStockFromItems(String items){for(String x:items.split(";")){String[] a=x.split(",");if(a.length<2)continue;try{double q=Double.parseDouble(a[1]);for(Product p:products)if(p.n.equals(a[0].trim()))p.stock=Math.max(0,p.stock-q);}catch(Exception e){}}}

    void paymentDialog(String customer){EditText a=new EditText(this);a.setHint("Payment received");a.setInputType(2|8192);new AlertDialog.Builder(this).setTitle("Record Payment").setView(a).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{try{double pay=Double.parseDouble(a.getText().toString());if(pay<=0)throw new Exception();for(int i=deliveries.size()-1;i>=0&&pay>0;i--){Delivery x=deliveries.get(i);if(!x.customer.equals(customer))continue;double p=Math.min(pay,x.pending());x.paid+=p;pay-=p;}save();showCustomer(customer);}catch(Exception e){Toast.makeText(this,"Invalid payment",Toast.LENGTH_SHORT).show();}}).show();}

    void productDialog(int i){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);EditText n=new EditText(this),a=new EditText(this),s=new EditText(this),q=new EditText(this);n.setHint("Rice name");a.setHint("Cost/kg");s.setHint("Sell/kg");q.setHint("Stock kg");b.addView(n);b.addView(a);b.addView(s);b.addView(q);if(i>=0){Product p=products.get(i);n.setText(p.n);a.setText(""+p.buy);s.setText(""+p.sell);q.setText(""+p.stock);}new AlertDialog.Builder(this).setTitle(i<0?"Add Product":"Edit Product").setView(b).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{try{String name=n.getText().toString().trim();double buy=Double.parseDouble(a.getText().toString()),sell=Double.parseDouble(s.getText().toString()),stock=Double.parseDouble(q.getText().toString());if(i<0)products.add(new Product(name,buy,sell,stock));else{Product p=products.get(i);p.n=name;p.buy=buy;p.sell=sell;p.stock=stock;}save();showStock();}catch(Exception e){Toast.makeText(this,"Invalid product",Toast.LENGTH_SHORT).show();}}).show();}
    void addStock(int i){EditText q=new EditText(this);q.setHint("Quantity kg");q.setInputType(2|8192);new AlertDialog.Builder(this).setTitle("Add Stock").setView(q).setNegativeButton("CANCEL",null).setPositiveButton("ADD",(d,w)->{try{products.get(i).stock+=Double.parseDouble(q.getText().toString());save();showStock();}catch(Exception e){}}).show();}
    void expenseDialog(){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);EditText n=new EditText(this),a=new EditText(this);n.setHint("Expense name");a.setHint("Amount");b.addView(n);b.addView(a);new AlertDialog.Builder(this).setTitle("Add Expense").setView(b).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{try{expenses.add(new Expense(dk(),n.getText().toString(),Double.parseDouble(a.getText().toString())));save();showHome();}catch(Exception e){}}).show();}
    void pickDate(boolean salesPage){new DatePickerDialog(this,(v,y,m,d)->{selected.set(y,m,d);if(salesPage)showSales();else showHome();},selected.get(1),selected.get(2),selected.get(5)).show();}
}
