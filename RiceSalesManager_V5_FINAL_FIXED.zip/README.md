# RiceSales Manager V5 Final Fixed

ZIP-upload Android project for GitHub Actions.

Features:
- Home dashboard
- Customers
- Customer account: total kg, total bill, received, pending
- Date-wise delivery history and item details
- Record payment
- Stock and products
- Sales / delivery
- Daily, monthly and yearly reports
- Expenses and net profit
- RiceSales Manager launcher icon

Important build fix:
- SharedPreferences import is included.
- Product loop lambda uses a final index variable, so Java 17 lambda compilation is valid.
- LayoutParams are correctly typed.

GitHub:
1. Upload this ZIP to the repository root with this exact filename.
2. Replace .github/workflows/build-apk.yml with the workflow included here.
3. Run the workflow manually.
