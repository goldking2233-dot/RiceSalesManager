# RiceSales Manager Professional v7

Fresh rebuild with:
- Dashboard
- Customer/shop accounts
- Date-wise sales
- Total kg, total bills, received and pending
- Delivery/sale entry
- Stock management
- Daily/monthly/yearly reports
- Expenses and net profit
- Bill details and sharing
- Customer account sharing
- App logo
- Local data persistence

GitHub Actions builds the project directly. No ZIP extraction is required inside the project itself.
