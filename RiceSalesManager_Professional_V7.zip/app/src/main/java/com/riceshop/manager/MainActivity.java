package com.riceshop.manager;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int GREEN=Color.rgb(11,107,58), GREEN2=Color.rgb(22,131,74), LIGHT=Color.rgb(242,248,244);
    private static final int DARK=Color.rgb(24,38,30), MUTED=Color.rgb(96,112,102), RED=Color.rgb(190,55,55);
    private LinearLayout content;
    private TextView pageTitle, pageSubtitle;
    private SharedPreferences db;
    private final ArrayList<Product> products=new ArrayList<>();
    private final ArrayList<Customer> customers=new ArrayList<>();
    private final ArrayList<Sale> sales=new ArrayList<>();
    private final ArrayList<Expense> expenses=new ArrayList<>();
    private Calendar selected=Calendar.getInstance();
    private int billCounter=1001;

    static class Product { String name; double cost,sell,stock; Product(String n,double c,double s,double q){name=n;cost=c;sell=s;stock=q;} }
    static class Customer { String name,phone; Customer(String n,String p){name=n;phone=p;} }
    static class Sale {
        String id,date,customer,product; double kg,bill,received;
        Sale(String i,String d,String c,String p,double k,double b,double r){id=i;date=d;customer=c;product=p;kg=k;bill=b;received=r;}
        double pending(){return Math.max(0,bill-received);}
    }
    static class Expense { String date,note; double amount; Expense(String d,String n,double a){date=d;note=n;amount=a;} }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db=getSharedPreferences("rice_manager_pro",MODE_PRIVATE);
        load();
        buildShell();
        showHome();
    }

    private String clean(String s){return s.replace("|"," ").replace("~"," ").replace("\n"," ");}
    private String money(double n){return "₹"+String.format(Locale.US,"%.2f",n);}
    private String day(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.getTime());}
    private String month(){return new SimpleDateFormat("yyyy-MM",Locale.US).format(selected.getTime());}
    private String year(){return new SimpleDateFormat("yyyy",Locale.US).format(selected.getTime());}
    private String prettyDate(String d){try{return new SimpleDateFormat("dd MMM yyyy",Locale.US).format(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(d));}catch(Exception e){return d;}}

    private GradientDrawable bg(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    private TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(14,10,14,10);return t;}
    private Button action(String s){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(bg(GREEN2,18));return b;}
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setPadding(12,8,12,8);return e;}

    private void buildShell(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.VERTICAL);top.setPadding(16,10,10,8);top.setBackgroundColor(GREEN);
        LinearLayout titleRow=new LinearLayout(this);titleRow.setGravity(Gravity.CENTER_VERTICAL);
        pageTitle=text("RiceSales Manager",21,Color.WHITE);pageTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        titleRow.addView(pageTitle,new LinearLayout.LayoutParams(0,48,1));
        TextView settings=text("⚙",26,Color.WHITE);settings.setGravity(Gravity.CENTER);settings.setOnClickListener(v->showSettings());titleRow.addView(settings,new LinearLayout.LayoutParams(52,48));
        top.addView(titleRow);
        pageSubtitle=text("",13,Color.rgb(215,239,224));top.addView(pageSubtitle);
        root.addView(top);

        ScrollView scroll=new ScrollView(this);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(12,12,12,18);
        scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this);nav.setPadding(5,5,5,6);nav.setBackgroundColor(Color.WHITE);
        String[] labels={"Home","Customers","Stock","Sales","Reports"};
        for(int i=0;i<labels.length;i++){
            final int tab=i;
            TextView n=text(labels[i],11,MUTED);n.setGravity(Gravity.CENTER);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            n.setOnClickListener(v->{if(tab==0)showHome();else if(tab==1)showCustomers();else if(tab==2)showStock();else if(tab==3)showSales();else showReports();});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,58,1);lp.setMargins(3,2,3,2);nav.addView(n,lp);
        }
        root.addView(nav);
        setContentView(root);
    }

    private void clearPage(String title,String subtitle){
        content.removeAllViews();pageTitle.setText(title);pageSubtitle.setText(subtitle);
    }
    private TextView heading(String s){TextView t=text(s,18,GREEN);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void addGap(int h){Space sp=new Space(this);content.addView(sp,new LinearLayout.LayoutParams(1,h));}
    private TextView card(String s){TextView t=text(s,15,DARK);t.setBackground(bg(LIGHT,20));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,5,0,5);content.addView(t,lp);return t;}

    private double salesFor(String prefix){double n=0;for(Sale s:sales)if(s.date.startsWith(prefix))n+=s.bill;return n;}
    private double receivedFor(String prefix){double n=0;for(Sale s:sales)if(s.date.startsWith(prefix))n+=s.received;return n;}
    private double pendingFor(String prefix){double n=0;for(Sale s:sales)if(s.date.startsWith(prefix))n+=s.pending();return n;}
    private double kgFor(String prefix){double n=0;for(Sale s:sales)if(s.date.startsWith(prefix))n+=s.kg;return n;}
    private double grossProfit(String prefix){double n=0;for(Sale s:sales)if(s.date.startsWith(prefix)){Product p=findProduct(s.product);if(p!=null)n+=(p.sell-p.cost)*s.kg;}return n;}
    private double expensesFor(String prefix){double n=0;for(Expense e:expenses)if(e.date.startsWith(prefix))n+=e.amount;return n;}
    private Product findProduct(String name){for(Product p:products)if(p.name.equals(name))return p;return null;}

    private void showHome(){
        clearPage("Dashboard","Selected date: "+prettyDate(day()));
        LinearLayout r1=row();stat(r1,"TODAY SALES",money(salesFor(day())));stat(r1,"TODAY PROFIT",money(grossProfit(day())));
        LinearLayout r2=row();stat(r2,"TODAY KG",String.format(Locale.US,"%.1f kg",kgFor(day())));stat(r2,"PENDING",money(pendingFor(day())));
        LinearLayout r3=row();stat(r3,"MONTH SALES",money(salesFor(month())));stat(r3,"MONTH PROFIT",money(grossProfit(month())-expensesFor(month())));
        LinearLayout r4=row();stat(r4,"YEAR SALES",money(salesFor(year())));stat(r4,"YEAR PROFIT",money(grossProfit(year())-expensesFor(year())));
        Button date=action("Select Date");date.setOnClickListener(v->pickDate(0));content.addView(date);
        content.addView(heading("Today's Delivery"));
        int count=0;for(Sale s:sales)if(s.date.equals(day()))count++;
        card(count+" bills  •  "+String.format(Locale.US,"%.1f kg",kgFor(day()))+"  •  "+money(salesFor(day())));
        Button sale=action("+ New Sale");sale.setOnClickListener(v->showSales());content.addView(sale);
        Button customer=action("View Customer Accounts");customer.setOnClickListener(v->showCustomers());content.addView(customer);
        Button expense=action("+ Add Expense");expense.setOnClickListener(v->expenseDialog());content.addView(expense);
    }
    private LinearLayout row(){LinearLayout r=new LinearLayout(this);content.addView(r);return r;}
    private void stat(LinearLayout row,String label,String value){
        TextView t=text(label+"\n"+value,13,DARK);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER);t.setBackground(bg(LIGHT,18));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,82,1);lp.setMargins(3,3,3,3);row.addView(t,lp);
    }

    private void showCustomers(){
        clearPage("Customers","Track kg, bills, received and pending");
        Button add=action("+ Add Customer / Shop");add.setOnClickListener(v->customerDialog());content.addView(add);
        EditText search=input("Search customer or shop");content.addView(search);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable render=()->{
            list.removeAllViews();String q=search.getText().toString().toLowerCase(Locale.US);
            for(Customer c:customers){
                if(!c.name.toLowerCase(Locale.US).contains(q))continue;
                double kg=0,bill=0,received=0;
                for(Sale s:sales)if(s.customer.equals(c.name)){kg+=s.kg;bill+=s.bill;received+=s.received;}
                TextView r=text(c.name+"\n"+(c.phone.isEmpty()?"":c.phone+"\n")+"Kg sold: "+String.format(Locale.US,"%.1f",kg)+"  |  Bill: "+money(bill)+"\nReceived: "+money(received)+"  |  Pending: "+money(bill-received),15,DARK);
                r.setBackground(bg(LIGHT,18));r.setOnClickListener(v->showCustomer(c.name));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,5,0,5);list.addView(r,lp);
            }
        };
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){render.run();}public void afterTextChanged(android.text.Editable e){}});
        render.run();
    }

    private void showCustomer(String name){
        clearPage(name,"Customer account");
        double kg=0,bill=0,received=0;for(Sale s:sales)if(s.customer.equals(name)){kg+=s.kg;bill+=s.bill;received+=s.received;}
        card("TOTAL RICE SOLD\n"+String.format(Locale.US,"%.1f kg",kg));
        card("TOTAL BILL\n"+money(bill));
        card("AMOUNT RECEIVED\n"+money(received));
        TextView p=card("PENDING\n"+money(bill-received));p.setTextColor((bill-received)>0?RED:GREEN);
        Button pay=action("Record Payment");pay.setOnClickListener(v->paymentDialog(name));content.addView(pay);
        Button sale=action("New Sale For This Shop");sale.setOnClickListener(v->saleDialog(name));content.addView(sale);
        Button share=action("Share Account Summary");share.setOnClickListener(v->shareCustomer(name));content.addView(share);
        content.addView(heading("Date-wise Sales"));
        for(int i=sales.size()-1;i>=0;i--){
            Sale s=sales.get(i);if(!s.customer.equals(name))continue;
            TextView r=text(prettyDate(s.date)+"  •  Bill #"+s.id+"\n"+s.product+"  "+String.format(Locale.US,"%.1f kg",s.kg)+" × "+money(s.bill/s.kg)+"\nBill "+money(s.bill)+"  |  Received "+money(s.received)+"  |  Pending "+money(s.pending()),14,DARK);
            r.setBackground(bg(LIGHT,18));r.setOnClickListener(v->billDialog(s));content.addView(r,new LinearLayout.LayoutParams(-1,-2));
        }
    }

    private void showStock(){
        clearPage("Stock","Current rice stock and selling prices");
        Button add=action("+ Add Rice Product");add.setOnClickListener(v->productDialog(-1));content.addView(add);
        for(int i=0;i<products.size();i++){
            final int index=i;Product p=products.get(i);
            LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(14,12,14,12);box.setBackground(bg(LIGHT,18));
            TextView n=text(p.name,18,GREEN);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);box.addView(n);
            box.addView(text("Cost "+money(p.cost)+"  •  Sell "+money(p.sell)+"\nStock "+String.format(Locale.US,"%.1f kg",p.stock),14,DARK));
            LinearLayout buttons=new LinearLayout(this);
            Button addStock=action("Add Stock");addStock.setOnClickListener(v->addStockDialog(index));
            Button edit=action("Edit");edit.setOnClickListener(v->productDialog(index));
            buttons.addView(addStock,new LinearLayout.LayoutParams(0,54,1));LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,54,1);ep.setMargins(6,0,0,0);buttons.addView(edit,ep);
            box.addView(buttons);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.setMargins(0,6,0,6);content.addView(box,bp);
        }
    }

    private void showSales(){
        clearPage("Sales","Daily sale and delivery bills");
        Button date=action("Date: "+prettyDate(day()));date.setOnClickListener(v->pickDate(1));content.addView(date);
        Button add=action("+ New Sale / Delivery");add.setOnClickListener(v->saleDialog(""));content.addView(add);
        content.addView(heading("Sales on "+prettyDate(day())));
        for(int i=sales.size()-1;i>=0;i--){Sale s=sales.get(i);if(!s.date.equals(day()))continue;
            TextView r=text("Bill #"+s.id+"  •  "+s.customer+"\n"+s.product+"  "+String.format(Locale.US,"%.1f kg",s.kg)+"  •  "+money(s.bill)+"\nReceived "+money(s.received)+"  •  Pending "+money(s.pending()),14,DARK);
            r.setBackground(bg(LIGHT,18));r.setOnClickListener(v->billDialog(s));content.addView(r,new LinearLayout.LayoutParams(-1,-2));
        }
    }

    private void showReports(){
        clearPage("Reports","Daily, monthly and yearly business summary");
        Button d=action("Change Selected Date");d.setOnClickListener(v->pickDate(2));content.addView(d);
        reportBlock("DAILY • "+prettyDate(day()),day());
        reportBlock("MONTHLY • "+month(),month());
        reportBlock("YEARLY • "+year(),year());
    }
    private void reportBlock(String title,String prefix){
        content.addView(heading(title));
        double gross=grossProfit(prefix),exp=expensesFor(prefix);
        card("Rice sold   "+String.format(Locale.US,"%.1f kg",kgFor(prefix))+
             "\nSales       "+money(salesFor(prefix))+
             "\nReceived    "+money(receivedFor(prefix))+
             "\nPending     "+money(pendingFor(prefix))+
             "\nGross Profit "+money(gross)+
             "\nExpenses    "+money(exp)+
             "\nNET PROFIT  "+money(gross-exp));
    }

    private void showSettings(){
        clearPage("Settings","App and data tools");
        Button shop=action("Shop Details");shop.setOnClickListener(v->shopDialog());content.addView(shop);
        Button export=action("Share / Backup Summary");export.setOnClickListener(v->shareAll());content.addView(export);
        Button reset=action("Reset Demo Data");reset.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Reset?").setMessage("This deletes saved customers, sales, stock and expenses.").setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->{db.edit().clear().apply();products.clear();customers.clear();sales.clear();expenses.clear();billCounter=1001;loadDefaults();save();showHome();}).show());content.addView(reset);
        content.addView(text("\nRiceSales Manager v7.0\nProfessional customer + delivery edition",14,MUTED));
    }

    private void customerDialog(){
        LinearLayout box=vertical();EditText n=input("Shop / customer name");EditText p=input("Phone number");box.addView(n);box.addView(p);
        new AlertDialog.Builder(this).setTitle("Add Customer").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String name=n.getText().toString().trim();if(name.isEmpty())return;customers.add(new Customer(name,p.getText().toString().trim()));save();showCustomers();}).show();
    }

    private void saleDialog(String preset){
        if(customers.isEmpty()){customerDialog();return;}
        LinearLayout box=vertical();
        Spinner cs=new Spinner(this);String[] cn=new String[customers.size()];for(int i=0;i<customers.size();i++)cn[i]=customers.get(i).name;cs.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,cn));
        if(!preset.isEmpty())for(int i=0;i<cn.length;i++)if(cn[i].equals(preset))cs.setSelection(i);
        Spinner ps=new Spinner(this);String[] pn=new String[products.size()];for(int i=0;i<products.size();i++)pn[i]=products.get(i).name;ps.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,pn));
        EditText kg=input("Quantity (kg)");kg.setInputType(2|8192);
        TextView rate=text("Select rice and quantity",14,MUTED);
        TextView total=text("Total: ₹0.00",18,GREEN);total.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        EditText received=input("Amount received now");received.setInputType(2|8192);
        ps.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){Product x=products.get(pos);rate.setText("Cost "+money(x.cost)+"  •  Sell "+money(x.sell)+"  •  Stock "+String.format(Locale.US,"%.1f kg",x.stock));}});
        TextView calc=total;kg.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){try{Product x=products.get(ps.getSelectedItemPosition());double q=Double.parseDouble(s.toString());calc.setText("Total: "+money(q*x.sell)+"   Profit: "+money(q*(x.sell-x.cost)));}catch(Exception e){calc.setText("Total: ₹0.00");}}public void afterTextChanged(android.text.Editable e){}});
        box.addView(text("Customer / Shop",13,MUTED));box.addView(cs);box.addView(text("Rice",13,MUTED));box.addView(ps);box.addView(rate);box.addView(kg);box.addView(total);box.addView(received);
        new AlertDialog.Builder(this).setTitle("New Sale / Delivery").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save Sale",(d,w)->{
            try{
                Product p=products.get(ps.getSelectedItemPosition());double q=Double.parseDouble(kg.getText().toString());
                if(q<=0||q>p.stock&&p.stock>0)throw new Exception();
                double bill=q*p.sell;double rec=received.getText().toString().trim().isEmpty()?0:Double.parseDouble(received.getText().toString());
                String id=""+billCounter++;sales.add(new Sale(id,day(),cs.getSelectedItem().toString(),p.name,q,bill,Math.min(rec,bill)));
                p.stock=Math.max(0,p.stock-q);save();showCustomer(cs.getSelectedItem().toString());
            }catch(Exception e){Toast.makeText(this,"Check quantity, stock and amount.",Toast.LENGTH_SHORT).show();}
        }).show();
    }

    private void paymentDialog(String customer){
        EditText a=input("Payment amount");a.setInputType(2|8192);
        new AlertDialog.Builder(this).setTitle("Record Payment").setView(a).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
            try{double pay=Double.parseDouble(a.getText().toString());for(int i=sales.size()-1;i>=0&&pay>0;i--){Sale s=sales.get(i);if(s.customer.equals(customer)){double add=Math.min(pay,s.pending());s.received+=add;pay-=add;}}save();showCustomer(customer);}catch(Exception e){Toast.makeText(this,"Enter a valid amount.",Toast.LENGTH_SHORT).show();}
        }).show();
    }

    private void billDialog(Sale s){
        new AlertDialog.Builder(this).setTitle("Bill #"+s.id)
            .setMessage("Customer: "+s.customer+"\nDate: "+prettyDate(s.date)+"\n\nRice: "+s.product+"\nQuantity: "+String.format(Locale.US,"%.1f kg",s.kg)+"\nRate: "+money(s.bill/s.kg)+"\n\nBill: "+money(s.bill)+"\nReceived: "+money(s.received)+"\nPending: "+money(s.pending()))
            .setNegativeButton("Close",null).setPositiveButton("Share",(d,w)->shareText("RiceSales Manager - Bill #"+s.id+"\nCustomer: "+s.customer+"\nDate: "+prettyDate(s.date)+"\n"+s.product+" - "+s.kg+" kg x "+money(s.bill/s.kg)+"\nBill: "+money(s.bill)+"\nReceived: "+money(s.received)+"\nPending: "+money(s.pending()))).show();
    }

    private void shareCustomer(String name){
        StringBuilder out=new StringBuilder("RiceSales Manager - "+name+"\n");
        double kg=0,b=0,r=0;for(Sale s:sales)if(s.customer.equals(name)){kg+=s.kg;b+=s.bill;r+=s.received;}
        out.append("Total kg: ").append(kg).append("\nTotal bill: ").append(money(b)).append("\nReceived: ").append(money(r)).append("\nPending: ").append(money(b-r)).append("\n\n");
        for(Sale s:sales)if(s.customer.equals(name))out.append(prettyDate(s.date)).append(" | ").append(s.product).append(" ").append(s.kg).append(" kg | ").append(money(s.bill)).append(" | Pending ").append(money(s.pending())).append("\n");
        shareText(out.toString());
    }
    private void shareAll(){shareText("RiceSales Manager\nYear sales: "+money(salesFor(year()))+"\nYear profit: "+money(grossProfit(year())-expensesFor(year()))+"\nYear pending: "+money(pendingFor(year()))+"\nYear kg: "+kgFor(year()));}
    private void shareText(String body){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,body);startActivity(Intent.createChooser(i,"Share with"));}

    private void productDialog(int index){
        LinearLayout box=vertical();EditText n=input("Rice name"),c=input("Cost per kg"),s=input("Selling price per kg"),q=input("Current stock kg");c.setInputType(2|8192);s.setInputType(2|8192);q.setInputType(2|8192);box.addView(n);box.addView(c);box.addView(s);box.addView(q);
        if(index>=0){Product p=products.get(index);n.setText(p.name);c.setText(""+p.cost);s.setText(""+p.sell);q.setText(""+p.stock);}
        new AlertDialog.Builder(this).setTitle(index<0?"Add Rice Product":"Edit Rice Product").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{try{String name=n.getText().toString().trim();double co=Double.parseDouble(c.getText().toString()),se=Double.parseDouble(s.getText().toString()),st=Double.parseDouble(q.getText().toString());if(index<0)products.add(new Product(name,co,se,st));else{Product p=products.get(index);p.name=name;p.cost=co;p.sell=se;p.stock=st;}save();showStock();}catch(Exception e){Toast.makeText(this,"Enter valid product details.",Toast.LENGTH_SHORT).show();}}).show();
    }
    private void addStockDialog(int index){EditText q=input("Add stock quantity (kg)");q.setInputType(2|8192);new AlertDialog.Builder(this).setTitle("Add Stock").setView(q).setNegativeButton("Cancel",null).setPositiveButton("Add",(d,w)->{try{products.get(index).stock+=Double.parseDouble(q.getText().toString());save();showStock();}catch(Exception e){}}).show();}
    private void expenseDialog(){LinearLayout box=vertical();EditText n=input("Expense name"),a=input("Amount");a.setInputType(2|8192);box.addView(n);box.addView(a);new AlertDialog.Builder(this).setTitle("Add Expense").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{try{expenses.add(new Expense(day(),n.getText().toString(),Double.parseDouble(a.getText().toString())));save();showHome();}catch(Exception e){}}).show();}
    private void shopDialog(){EditText n=input("Shop name");n.setText(db.getString("shop","RiceSales Manager"));new AlertDialog.Builder(this).setTitle("Shop Details").setView(n).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{db.edit().putString("shop",n.getText().toString()).apply();pageTitle.setText(n.getText().toString());}).show();}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(6,2,6,2);return l;}

    private void pickDate(int page){new DatePickerDialog(this,(v,y,m,d)->{selected.set(y,m,d);if(page==0)showHome();else if(page==1)showSales();else showReports();},selected.get(Calendar.YEAR),selected.get(Calendar.MONTH),selected.get(Calendar.DAY_OF_MONTH)).show();}

    private void load(){
        products.clear();customers.clear();sales.clear();expenses.clear();
        loadProducts(db.getString("products",""));loadCustomers(db.getString("customers",""));loadSales(db.getString("sales",""));loadExpenses(db.getString("expenses",""));
        billCounter=db.getInt("billCounter",1001);
        if(products.isEmpty()&&customers.isEmpty()&&sales.isEmpty())loadDefaults();
    }
    private void loadDefaults(){
        products.add(new Product("Nasreen",102,107,0));products.add(new Product("Suber",79,85,0));products.add(new Product("Tajmahal",40,45,0));products.add(new Product("Nasreen 2",95,102,0));
    }
    private void loadProducts(String raw){if(raw.isEmpty())return;for(String r:raw.split("\\|",-1)){String[] x=r.split("~",-1);try{if(x.length>=4)products.add(new Product(x[0],Double.parseDouble(x[1]),Double.parseDouble(x[2]),Double.parseDouble(x[3])));}catch(Exception ignored){}}}
    private void loadCustomers(String raw){if(raw.isEmpty())return;for(String r:raw.split("\\|",-1)){String[] x=r.split("~",-1);if(x.length>=2)customers.add(new Customer(x[0],x[1]));}}
    private void loadSales(String raw){if(raw.isEmpty())return;for(String r:raw.split("\\|",-1)){String[] x=r.split("~",-1);try{if(x.length>=7)sales.add(new Sale(x[0],x[1],x[2],x[3],Double.parseDouble(x[4]),Double.parseDouble(x[5]),Double.parseDouble(x[6])));}catch(Exception ignored){}}}
    private void loadExpenses(String raw){if(raw.isEmpty())return;for(String r:raw.split("\\|",-1)){String[] x=r.split("~",-1);try{if(x.length>=3)expenses.add(new Expense(x[0],x[1],Double.parseDouble(x[2])));}catch(Exception ignored){}}}

    private void save(){
        StringBuilder p=new StringBuilder();for(Product x:products){if(p.length()>0)p.append("|");p.append(clean(x.name)).append("~").append(x.cost).append("~").append(x.sell).append("~").append(x.stock);}
        StringBuilder c=new StringBuilder();for(Customer x:customers){if(c.length()>0)c.append("|");c.append(clean(x.name)).append("~").append(clean(x.phone));}
        StringBuilder s=new StringBuilder();for(Sale x:sales){if(s.length()>0)s.append("|");s.append(x.id).append("~").append(x.date).append("~").append(clean(x.customer)).append("~").append(clean(x.product)).append("~").append(x.kg).append("~").append(x.bill).append("~").append(x.received);}
        StringBuilder e=new StringBuilder();for(Expense x:expenses){if(e.length()>0)e.append("|");e.append(x.date).append("~").append(clean(x.note)).append("~").append(x.amount);}
        db.edit().putString("products",p.toString()).putString("customers",c.toString()).putString("sales",s.toString()).putString("expenses",e.toString()).putInt("billCounter",billCounter).apply();
    }
}
